"""
模块: Ising

功能: 提供Ising相关函数
"""
from kaiwu.ising._interface import details

__all__ = ["details"]
